﻿Imports MySql.Data.MySqlClient
Public Class frmAcceso

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnIngresar.Click
        Me.Hide()
        Main.Show()
    End Sub
End Class

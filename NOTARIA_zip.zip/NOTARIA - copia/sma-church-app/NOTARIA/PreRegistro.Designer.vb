﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PreRegistro
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCerrar = New System.Windows.Forms.Button()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.txtapemat = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtapepat = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtnombre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.cmbannonac = New System.Windows.Forms.ComboBox()
        Me.cmbmesnac = New System.Windows.Forms.ComboBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.cmbdianac = New System.Windows.Forms.ComboBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtnommama = New System.Windows.Forms.TextBox()
        Me.txtnompapa = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtnomapm = New System.Windows.Forms.TextBox()
        Me.txtnomapp = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtnomamm = New System.Windows.Forms.TextBox()
        Me.txtnomamp = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtnommad = New System.Windows.Forms.TextBox()
        Me.txtnompad = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cmbannobau = New System.Windows.Forms.ComboBox()
        Me.cmbmesbau = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.cmbdiabau = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCerrar
        '
        Me.btnCerrar.Location = New System.Drawing.Point(169, 465)
        Me.btnCerrar.Name = "btnCerrar"
        Me.btnCerrar.Size = New System.Drawing.Size(75, 23)
        Me.btnCerrar.TabIndex = 19
        Me.btnCerrar.Text = "&Cerrar"
        Me.btnCerrar.UseVisualStyleBackColor = True
        '
        'BtnGuardar
        '
        Me.BtnGuardar.Location = New System.Drawing.Point(70, 465)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Size = New System.Drawing.Size(75, 23)
        Me.BtnGuardar.TabIndex = 18
        Me.BtnGuardar.Text = "&Guardar"
        Me.BtnGuardar.UseVisualStyleBackColor = True
        '
        'txtapemat
        '
        Me.txtapemat.Location = New System.Drawing.Point(100, 100)
        Me.txtapemat.MaxLength = 45
        Me.txtapemat.Name = "txtapemat"
        Me.txtapemat.Size = New System.Drawing.Size(343, 20)
        Me.txtapemat.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 100)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 44
        Me.Label4.Text = "Apellido Materno:"
        '
        'txtapepat
        '
        Me.txtapepat.Location = New System.Drawing.Point(100, 74)
        Me.txtapepat.MaxLength = 45
        Me.txtapepat.Name = "txtapepat"
        Me.txtapepat.Size = New System.Drawing.Size(343, 20)
        Me.txtapepat.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 42
        Me.Label3.Text = "Apellido Paterno:"
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(100, 48)
        Me.txtnombre.MaxLength = 70
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(343, 20)
        Me.txtnombre.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(9, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 40
        Me.Label2.Text = "Nombre :"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(-3, -6)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(100, 20)
        Me.txtid.TabIndex = 39
        Me.txtid.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(17, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(205, 17)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Formulario de Pre-Registro"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label39)
        Me.GroupBox1.Controls.Add(Me.cmbannonac)
        Me.GroupBox1.Controls.Add(Me.cmbmesnac)
        Me.GroupBox1.Controls.Add(Me.Label38)
        Me.GroupBox1.Controls.Add(Me.cmbdianac)
        Me.GroupBox1.Controls.Add(Me.Label37)
        Me.GroupBox1.Location = New System.Drawing.Point(448, 14)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox1.Size = New System.Drawing.Size(314, 52)
        Me.GroupBox1.TabIndex = 54
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Fecha de Nacimiento"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(218, 21)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(26, 13)
        Me.Label39.TabIndex = 59
        Me.Label39.Text = "Año"
        '
        'cmbannonac
        '
        Me.cmbannonac.AutoCompleteCustomSource.AddRange(New String() {"Selecciona"})
        Me.cmbannonac.FormatString = "N0"
        Me.cmbannonac.FormattingEnabled = True
        Me.cmbannonac.Location = New System.Drawing.Point(249, 21)
        Me.cmbannonac.Name = "cmbannonac"
        Me.cmbannonac.Size = New System.Drawing.Size(58, 21)
        Me.cmbannonac.TabIndex = 6
        '
        'cmbmesnac
        '
        Me.cmbmesnac.FormattingEnabled = True
        Me.cmbmesnac.Items.AddRange(New Object() {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"})
        Me.cmbmesnac.Location = New System.Drawing.Point(122, 19)
        Me.cmbmesnac.Name = "cmbmesnac"
        Me.cmbmesnac.Size = New System.Drawing.Size(92, 21)
        Me.cmbmesnac.TabIndex = 5
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(89, 24)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(27, 13)
        Me.Label38.TabIndex = 56
        Me.Label38.Text = "Mes"
        '
        'cmbdianac
        '
        Me.cmbdianac.FormattingEnabled = True
        Me.cmbdianac.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"})
        Me.cmbdianac.Location = New System.Drawing.Point(36, 21)
        Me.cmbdianac.Name = "cmbdianac"
        Me.cmbdianac.Size = New System.Drawing.Size(43, 21)
        Me.cmbdianac.TabIndex = 4
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(8, 21)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(23, 13)
        Me.Label37.TabIndex = 54
        Me.Label37.Text = "Dia"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtnommama)
        Me.GroupBox2.Controls.Add(Me.txtnompapa)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Location = New System.Drawing.Point(9, 124)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(751, 81)
        Me.GroupBox2.TabIndex = 57
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Nombre de Papas"
        '
        'txtnommama
        '
        Me.txtnommama.Location = New System.Drawing.Point(91, 44)
        Me.txtnommama.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnommama.MaxLength = 120
        Me.txtnommama.Name = "txtnommama"
        Me.txtnommama.Size = New System.Drawing.Size(653, 20)
        Me.txtnommama.TabIndex = 11
        '
        'txtnompapa
        '
        Me.txtnompapa.Location = New System.Drawing.Point(91, 21)
        Me.txtnompapa.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnompapa.MaxLength = 120
        Me.txtnompapa.Name = "txtnompapa"
        Me.txtnompapa.Size = New System.Drawing.Size(653, 20)
        Me.txtnompapa.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(10, 45)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Mama :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(9, 21)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Papa :"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtnomapm)
        Me.GroupBox3.Controls.Add(Me.txtnomapp)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Location = New System.Drawing.Point(10, 210)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(751, 81)
        Me.GroupBox3.TabIndex = 58
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Nombre de Abuelos Paternos"
        '
        'txtnomapm
        '
        Me.txtnomapm.Location = New System.Drawing.Point(90, 44)
        Me.txtnomapm.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnomapm.MaxLength = 120
        Me.txtnomapm.Name = "txtnomapm"
        Me.txtnomapm.Size = New System.Drawing.Size(654, 20)
        Me.txtnomapm.TabIndex = 13
        '
        'txtnomapp
        '
        Me.txtnomapp.Location = New System.Drawing.Point(90, 21)
        Me.txtnomapp.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnomapp.MaxLength = 120
        Me.txtnomapp.Name = "txtnomapp"
        Me.txtnomapp.Size = New System.Drawing.Size(654, 20)
        Me.txtnomapp.TabIndex = 12
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 45)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 13)
        Me.Label8.TabIndex = 1
        Me.Label8.Text = "Abuela :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(9, 21)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Abuelo :"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtnomamm)
        Me.GroupBox4.Controls.Add(Me.txtnomamp)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Location = New System.Drawing.Point(10, 293)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox4.Size = New System.Drawing.Size(751, 81)
        Me.GroupBox4.TabIndex = 59
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Nombre de Abuelos Maternos"
        '
        'txtnomamm
        '
        Me.txtnomamm.Location = New System.Drawing.Point(90, 44)
        Me.txtnomamm.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnomamm.MaxLength = 120
        Me.txtnomamm.Name = "txtnomamm"
        Me.txtnomamm.Size = New System.Drawing.Size(654, 20)
        Me.txtnomamm.TabIndex = 15
        '
        'txtnomamp
        '
        Me.txtnomamp.Location = New System.Drawing.Point(90, 21)
        Me.txtnomamp.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnomamp.MaxLength = 120
        Me.txtnomamp.Name = "txtnomamp"
        Me.txtnomamp.Size = New System.Drawing.Size(654, 20)
        Me.txtnomamp.TabIndex = 14
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(10, 45)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(46, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Abuela :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(9, 21)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Abuelo :"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtnommad)
        Me.GroupBox5.Controls.Add(Me.txtnompad)
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Location = New System.Drawing.Point(10, 379)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Size = New System.Drawing.Size(751, 81)
        Me.GroupBox5.TabIndex = 60
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Nombre de Padinos"
        '
        'txtnommad
        '
        Me.txtnommad.Location = New System.Drawing.Point(90, 44)
        Me.txtnommad.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnommad.MaxLength = 120
        Me.txtnommad.Name = "txtnommad"
        Me.txtnommad.Size = New System.Drawing.Size(654, 20)
        Me.txtnommad.TabIndex = 17
        '
        'txtnompad
        '
        Me.txtnompad.Location = New System.Drawing.Point(90, 21)
        Me.txtnompad.Margin = New System.Windows.Forms.Padding(2)
        Me.txtnompad.MaxLength = 120
        Me.txtnompad.Name = "txtnompad"
        Me.txtnompad.Size = New System.Drawing.Size(654, 20)
        Me.txtnompad.TabIndex = 16
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(10, 45)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(51, 13)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Madrina :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(9, 21)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "Padrino :"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label5)
        Me.GroupBox6.Controls.Add(Me.cmbannobau)
        Me.GroupBox6.Controls.Add(Me.cmbmesbau)
        Me.GroupBox6.Controls.Add(Me.Label14)
        Me.GroupBox6.Controls.Add(Me.cmbdiabau)
        Me.GroupBox6.Controls.Add(Me.Label15)
        Me.GroupBox6.Location = New System.Drawing.Point(449, 71)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Size = New System.Drawing.Size(314, 52)
        Me.GroupBox6.TabIndex = 61
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Fecha de Bautizo"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(218, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(26, 13)
        Me.Label5.TabIndex = 59
        Me.Label5.Text = "Año"
        '
        'cmbannobau
        '
        Me.cmbannobau.FormattingEnabled = True
        Me.cmbannobau.Location = New System.Drawing.Point(249, 21)
        Me.cmbannobau.Name = "cmbannobau"
        Me.cmbannobau.Size = New System.Drawing.Size(58, 21)
        Me.cmbannobau.TabIndex = 9
        '
        'cmbmesbau
        '
        Me.cmbmesbau.FormattingEnabled = True
        Me.cmbmesbau.Items.AddRange(New Object() {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"})
        Me.cmbmesbau.Location = New System.Drawing.Point(122, 19)
        Me.cmbmesbau.Name = "cmbmesbau"
        Me.cmbmesbau.Size = New System.Drawing.Size(92, 21)
        Me.cmbmesbau.TabIndex = 8
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(89, 24)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(27, 13)
        Me.Label14.TabIndex = 56
        Me.Label14.Text = "Mes"
        '
        'cmbdiabau
        '
        Me.cmbdiabau.FormattingEnabled = True
        Me.cmbdiabau.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"})
        Me.cmbdiabau.Location = New System.Drawing.Point(36, 21)
        Me.cmbdiabau.Name = "cmbdiabau"
        Me.cmbdiabau.Size = New System.Drawing.Size(43, 21)
        Me.cmbdiabau.TabIndex = 7
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(8, 21)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(23, 13)
        Me.Label15.TabIndex = 54
        Me.Label15.Text = "Dia"
        '
        'PreRegistro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(777, 499)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnCerrar)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.txtapemat)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtapepat)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "PreRegistro"
        Me.Text = "Pre-Registro"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnCerrar As System.Windows.Forms.Button
    Friend WithEvents BtnGuardar As System.Windows.Forms.Button
    Friend WithEvents txtapemat As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtapepat As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents cmbannonac As System.Windows.Forms.ComboBox
    Friend WithEvents cmbmesnac As System.Windows.Forms.ComboBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents cmbdianac As System.Windows.Forms.ComboBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtnommama As System.Windows.Forms.TextBox
    Friend WithEvents txtnompapa As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtnomapm As System.Windows.Forms.TextBox
    Friend WithEvents txtnomapp As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtnomamm As System.Windows.Forms.TextBox
    Friend WithEvents txtnomamp As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents txtnommad As System.Windows.Forms.TextBox
    Friend WithEvents txtnompad As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmbannobau As System.Windows.Forms.ComboBox
    Friend WithEvents cmbmesbau As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents cmbdiabau As System.Windows.Forms.ComboBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
End Class

﻿Imports MySql.Data
Imports MySql.Data.MySqlClient
Module Module1
    Public stringConnection As String
    '  stringConnection = New MySqlConnection()
    '  stringConnection.ConnectionString = "server=localhost; user id=root; password=nota2012; database=test"

End Module

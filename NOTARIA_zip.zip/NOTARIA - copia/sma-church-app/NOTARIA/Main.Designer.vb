﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPre = New System.Windows.Forms.Button()
        Me.btnBau = New System.Windows.Forms.Button()
        Me.btnCon = New System.Windows.Forms.Button()
        Me.btnPri = New System.Windows.Forms.Button()
        Me.btnMat = New System.Windows.Forms.Button()
        Me.btnNul = New System.Windows.Forms.Button()
        Me.btnDef = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnAdmin = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnPre
        '
        Me.btnPre.Location = New System.Drawing.Point(16, 42)
        Me.btnPre.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnPre.Name = "btnPre"
        Me.btnPre.Size = New System.Drawing.Size(120, 49)
        Me.btnPre.TabIndex = 3
        Me.btnPre.Text = "Pre-Registro"
        Me.btnPre.UseVisualStyleBackColor = True
        '
        'btnBau
        '
        Me.btnBau.Location = New System.Drawing.Point(16, 94)
        Me.btnBau.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnBau.Name = "btnBau"
        Me.btnBau.Size = New System.Drawing.Size(120, 49)
        Me.btnBau.TabIndex = 4
        Me.btnBau.Text = "Bautizos"
        Me.btnBau.UseVisualStyleBackColor = True
        '
        'btnCon
        '
        Me.btnCon.Location = New System.Drawing.Point(16, 145)
        Me.btnCon.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnCon.Name = "btnCon"
        Me.btnCon.Size = New System.Drawing.Size(120, 49)
        Me.btnCon.TabIndex = 5
        Me.btnCon.Text = "Confirmaciones"
        Me.btnCon.UseVisualStyleBackColor = True
        '
        'btnPri
        '
        Me.btnPri.Location = New System.Drawing.Point(16, 199)
        Me.btnPri.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnPri.Name = "btnPri"
        Me.btnPri.Size = New System.Drawing.Size(120, 49)
        Me.btnPri.TabIndex = 6
        Me.btnPri.Text = "Primera Comunión"
        Me.btnPri.UseVisualStyleBackColor = True
        '
        'btnMat
        '
        Me.btnMat.Location = New System.Drawing.Point(16, 255)
        Me.btnMat.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnMat.Name = "btnMat"
        Me.btnMat.Size = New System.Drawing.Size(120, 49)
        Me.btnMat.TabIndex = 7
        Me.btnMat.Text = "Matrimonios"
        Me.btnMat.UseVisualStyleBackColor = True
        '
        'btnNul
        '
        Me.btnNul.Location = New System.Drawing.Point(16, 308)
        Me.btnNul.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnNul.Name = "btnNul"
        Me.btnNul.Size = New System.Drawing.Size(120, 49)
        Me.btnNul.TabIndex = 8
        Me.btnNul.Text = "Nulidades"
        Me.btnNul.UseVisualStyleBackColor = True
        '
        'btnDef
        '
        Me.btnDef.Location = New System.Drawing.Point(16, 361)
        Me.btnDef.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnDef.Name = "btnDef"
        Me.btnDef.Size = New System.Drawing.Size(120, 49)
        Me.btnDef.TabIndex = 9
        Me.btnDef.Text = "Defunciones"
        Me.btnDef.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(9, 10)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(155, 25)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Menú Principal"
        '
        'btnAdmin
        '
        Me.btnAdmin.Location = New System.Drawing.Point(16, 417)
        Me.btnAdmin.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnAdmin.Name = "btnAdmin"
        Me.btnAdmin.Size = New System.Drawing.Size(120, 49)
        Me.btnAdmin.TabIndex = 11
        Me.btnAdmin.Text = "Administración"
        Me.btnAdmin.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(178, 42)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(120, 49)
        Me.Button1.TabIndex = 12
        Me.Button1.Text = "Pre-Registro2"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(712, 473)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnAdmin)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDef)
        Me.Controls.Add(Me.btnNul)
        Me.Controls.Add(Me.btnMat)
        Me.Controls.Add(Me.btnPri)
        Me.Controls.Add(Me.btnCon)
        Me.Controls.Add(Me.btnBau)
        Me.Controls.Add(Me.btnPre)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "Main"
        Me.Text = "Main"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPre As System.Windows.Forms.Button
    Friend WithEvents btnBau As System.Windows.Forms.Button
    Friend WithEvents btnCon As System.Windows.Forms.Button
    Friend WithEvents btnPri As System.Windows.Forms.Button
    Friend WithEvents btnMat As System.Windows.Forms.Button
    Friend WithEvents btnNul As System.Windows.Forms.Button
    Friend WithEvents btnDef As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnAdmin As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class

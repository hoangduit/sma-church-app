﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PreRegistroOld
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtid = New System.Windows.Forms.TextBox()
        Me.txtnombre = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtapepat = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtapemat = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gpopapas = New System.Windows.Forms.GroupBox()
        Me.txtapematmama = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtapepatmama = New System.Windows.Forms.TextBox()
        Me.txtnombremama = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtapematpapa = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtapepatpapa = New System.Windows.Forms.TextBox()
        Me.txtnombrepapa = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.gpoabuelosPat = New System.Windows.Forms.GroupBox()
        Me.txtapematapm = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtapepatapm = New System.Windows.Forms.TextBox()
        Me.txtnombreapm = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtapematapp = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtapepatapp = New System.Windows.Forms.TextBox()
        Me.txtnombreapp = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.gpoabuelosmat = New System.Windows.Forms.GroupBox()
        Me.txtapematamm = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtapepatamm = New System.Windows.Forms.TextBox()
        Me.txtnombreamm = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtapematamp = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtapepatamp = New System.Windows.Forms.TextBox()
        Me.txtnombreamp = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.gpopadrinos = New System.Windows.Forms.GroupBox()
        Me.txtapematmad = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtapepatmad = New System.Windows.Forms.TextBox()
        Me.txtnombremad = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.txtapematpad = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtapepatpad = New System.Windows.Forms.TextBox()
        Me.txtnombrepad = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.BtnGuardar = New System.Windows.Forms.Button()
        Me.btnCerrar = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.cmbdia = New System.Windows.Forms.ComboBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.cmbmes = New System.Windows.Forms.ComboBox()
        Me.cmbanno = New System.Windows.Forms.ComboBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.gpopapas.SuspendLayout()
        Me.gpoabuelosPat.SuspendLayout()
        Me.gpoabuelosmat.SuspendLayout()
        Me.gpopadrinos.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pre-Registro"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(0, -7)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(100, 20)
        Me.txtid.TabIndex = 1
        Me.txtid.Visible = False
        '
        'txtnombre
        '
        Me.txtnombre.Location = New System.Drawing.Point(103, 46)
        Me.txtnombre.MaxLength = 70
        Me.txtnombre.Name = "txtnombre"
        Me.txtnombre.Size = New System.Drawing.Size(262, 20)
        Me.txtnombre.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Nombre :"
        '
        'txtapepat
        '
        Me.txtapepat.Location = New System.Drawing.Point(103, 72)
        Me.txtapepat.MaxLength = 45
        Me.txtapepat.Name = "txtapepat"
        Me.txtapepat.Size = New System.Drawing.Size(186, 20)
        Me.txtapepat.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(10, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Apellido Paterno:"
        '
        'txtapemat
        '
        Me.txtapemat.Location = New System.Drawing.Point(103, 98)
        Me.txtapemat.MaxLength = 45
        Me.txtapemat.Name = "txtapemat"
        Me.txtapemat.Size = New System.Drawing.Size(186, 20)
        Me.txtapemat.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(10, 98)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Apellido Materno:"
        '
        'gpopapas
        '
        Me.gpopapas.Controls.Add(Me.txtapematmama)
        Me.gpopapas.Controls.Add(Me.Label8)
        Me.gpopapas.Controls.Add(Me.txtapepatmama)
        Me.gpopapas.Controls.Add(Me.txtnombremama)
        Me.gpopapas.Controls.Add(Me.Label9)
        Me.gpopapas.Controls.Add(Me.Label10)
        Me.gpopapas.Controls.Add(Me.txtapematpapa)
        Me.gpopapas.Controls.Add(Me.Label13)
        Me.gpopapas.Controls.Add(Me.Label5)
        Me.gpopapas.Controls.Add(Me.Label12)
        Me.gpopapas.Controls.Add(Me.txtapepatpapa)
        Me.gpopapas.Controls.Add(Me.txtnombrepapa)
        Me.gpopapas.Controls.Add(Me.Label6)
        Me.gpopapas.Controls.Add(Me.Label7)
        Me.gpopapas.Location = New System.Drawing.Point(12, 131)
        Me.gpopapas.Name = "gpopapas"
        Me.gpopapas.Size = New System.Drawing.Size(727, 117)
        Me.gpopapas.TabIndex = 11
        Me.gpopapas.TabStop = False
        Me.gpopapas.Text = "Papas"
        '
        'txtapematmama
        '
        Me.txtapematmama.Location = New System.Drawing.Point(451, 87)
        Me.txtapematmama.MaxLength = 45
        Me.txtapematmama.Name = "txtapematmama"
        Me.txtapematmama.Size = New System.Drawing.Size(186, 20)
        Me.txtapematmama.TabIndex = 25
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(362, 87)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(89, 13)
        Me.Label8.TabIndex = 24
        Me.Label8.Text = "Apellido Materno:"
        '
        'txtapepatmama
        '
        Me.txtapepatmama.Location = New System.Drawing.Point(451, 61)
        Me.txtapepatmama.MaxLength = 45
        Me.txtapepatmama.Name = "txtapepatmama"
        Me.txtapepatmama.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatmama.TabIndex = 23
        '
        'txtnombremama
        '
        Me.txtnombremama.Location = New System.Drawing.Point(451, 38)
        Me.txtnombremama.MaxLength = 70
        Me.txtnombremama.Name = "txtnombremama"
        Me.txtnombremama.Size = New System.Drawing.Size(262, 20)
        Me.txtnombremama.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(364, 61)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(87, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Apellido Paterno:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(365, 38)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(50, 13)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Nombre :"
        '
        'txtapematpapa
        '
        Me.txtapematpapa.Location = New System.Drawing.Point(91, 87)
        Me.txtapematpapa.MaxLength = 45
        Me.txtapematpapa.Name = "txtapematpapa"
        Me.txtapematpapa.Size = New System.Drawing.Size(186, 20)
        Me.txtapematpapa.TabIndex = 17
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(489, 19)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(40, 13)
        Me.Label13.TabIndex = 19
        Me.Label13.Text = "Mama"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(2, 87)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Apellido Materno:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(128, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 13)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Papa"
        '
        'txtapepatpapa
        '
        Me.txtapepatpapa.Location = New System.Drawing.Point(91, 61)
        Me.txtapepatpapa.MaxLength = 45
        Me.txtapepatpapa.Name = "txtapepatpapa"
        Me.txtapepatpapa.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatpapa.TabIndex = 15
        '
        'txtnombrepapa
        '
        Me.txtnombrepapa.Location = New System.Drawing.Point(91, 38)
        Me.txtnombrepapa.MaxLength = 70
        Me.txtnombrepapa.Name = "txtnombrepapa"
        Me.txtnombrepapa.Size = New System.Drawing.Size(262, 20)
        Me.txtnombrepapa.TabIndex = 13
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(4, 61)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(87, 13)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Apellido Paterno:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(5, 38)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(50, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Nombre :"
        '
        'gpoabuelosPat
        '
        Me.gpoabuelosPat.Controls.Add(Me.txtapematapm)
        Me.gpoabuelosPat.Controls.Add(Me.Label11)
        Me.gpoabuelosPat.Controls.Add(Me.txtapepatapm)
        Me.gpoabuelosPat.Controls.Add(Me.txtnombreapm)
        Me.gpoabuelosPat.Controls.Add(Me.Label14)
        Me.gpoabuelosPat.Controls.Add(Me.Label15)
        Me.gpoabuelosPat.Controls.Add(Me.txtapematapp)
        Me.gpoabuelosPat.Controls.Add(Me.Label16)
        Me.gpoabuelosPat.Controls.Add(Me.Label17)
        Me.gpoabuelosPat.Controls.Add(Me.Label18)
        Me.gpoabuelosPat.Controls.Add(Me.txtapepatapp)
        Me.gpoabuelosPat.Controls.Add(Me.txtnombreapp)
        Me.gpoabuelosPat.Controls.Add(Me.Label19)
        Me.gpoabuelosPat.Controls.Add(Me.Label20)
        Me.gpoabuelosPat.Location = New System.Drawing.Point(12, 253)
        Me.gpoabuelosPat.Name = "gpoabuelosPat"
        Me.gpoabuelosPat.Size = New System.Drawing.Size(727, 117)
        Me.gpoabuelosPat.TabIndex = 26
        Me.gpoabuelosPat.TabStop = False
        Me.gpoabuelosPat.Text = "Abuelos Paternos"
        '
        'txtapematapm
        '
        Me.txtapematapm.Location = New System.Drawing.Point(451, 87)
        Me.txtapematapm.MaxLength = 45
        Me.txtapematapm.Name = "txtapematapm"
        Me.txtapematapm.Size = New System.Drawing.Size(186, 20)
        Me.txtapematapm.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(362, 87)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(89, 13)
        Me.Label11.TabIndex = 24
        Me.Label11.Text = "Apellido Materno:"
        '
        'txtapepatapm
        '
        Me.txtapepatapm.Location = New System.Drawing.Point(451, 61)
        Me.txtapepatapm.MaxLength = 45
        Me.txtapepatapm.Name = "txtapepatapm"
        Me.txtapepatapm.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatapm.TabIndex = 23
        '
        'txtnombreapm
        '
        Me.txtnombreapm.Location = New System.Drawing.Point(451, 38)
        Me.txtnombreapm.MaxLength = 70
        Me.txtnombreapm.Name = "txtnombreapm"
        Me.txtnombreapm.Size = New System.Drawing.Size(262, 20)
        Me.txtnombreapm.TabIndex = 21
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(364, 61)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(87, 13)
        Me.Label14.TabIndex = 22
        Me.Label14.Text = "Apellido Paterno:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(365, 38)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(50, 13)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Nombre :"
        '
        'txtapematapp
        '
        Me.txtapematapp.Location = New System.Drawing.Point(91, 87)
        Me.txtapematapp.MaxLength = 45
        Me.txtapematapp.Name = "txtapematapp"
        Me.txtapematapp.Size = New System.Drawing.Size(186, 20)
        Me.txtapematapp.TabIndex = 17
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(489, 19)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(46, 13)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "Abuela"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(2, 87)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(89, 13)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "Apellido Materno:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(128, 19)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(46, 13)
        Me.Label18.TabIndex = 18
        Me.Label18.Text = "Abuelo"
        '
        'txtapepatapp
        '
        Me.txtapepatapp.Location = New System.Drawing.Point(91, 61)
        Me.txtapepatapp.MaxLength = 45
        Me.txtapepatapp.Name = "txtapepatapp"
        Me.txtapepatapp.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatapp.TabIndex = 15
        '
        'txtnombreapp
        '
        Me.txtnombreapp.Location = New System.Drawing.Point(91, 38)
        Me.txtnombreapp.MaxLength = 70
        Me.txtnombreapp.Name = "txtnombreapp"
        Me.txtnombreapp.Size = New System.Drawing.Size(262, 20)
        Me.txtnombreapp.TabIndex = 13
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(4, 61)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(87, 13)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "Apellido Paterno:"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(5, 38)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(50, 13)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "Nombre :"
        '
        'gpoabuelosmat
        '
        Me.gpoabuelosmat.Controls.Add(Me.txtapematamm)
        Me.gpoabuelosmat.Controls.Add(Me.Label21)
        Me.gpoabuelosmat.Controls.Add(Me.txtapepatamm)
        Me.gpoabuelosmat.Controls.Add(Me.txtnombreamm)
        Me.gpoabuelosmat.Controls.Add(Me.Label22)
        Me.gpoabuelosmat.Controls.Add(Me.Label23)
        Me.gpoabuelosmat.Controls.Add(Me.txtapematamp)
        Me.gpoabuelosmat.Controls.Add(Me.Label24)
        Me.gpoabuelosmat.Controls.Add(Me.Label25)
        Me.gpoabuelosmat.Controls.Add(Me.Label26)
        Me.gpoabuelosmat.Controls.Add(Me.txtapepatamp)
        Me.gpoabuelosmat.Controls.Add(Me.txtnombreamp)
        Me.gpoabuelosmat.Controls.Add(Me.Label27)
        Me.gpoabuelosmat.Controls.Add(Me.Label28)
        Me.gpoabuelosmat.Location = New System.Drawing.Point(12, 376)
        Me.gpoabuelosmat.Name = "gpoabuelosmat"
        Me.gpoabuelosmat.Size = New System.Drawing.Size(727, 117)
        Me.gpoabuelosmat.TabIndex = 27
        Me.gpoabuelosmat.TabStop = False
        Me.gpoabuelosmat.Text = "Abuelos Maternos"
        '
        'txtapematamm
        '
        Me.txtapematamm.Location = New System.Drawing.Point(451, 87)
        Me.txtapematamm.MaxLength = 45
        Me.txtapematamm.Name = "txtapematamm"
        Me.txtapematamm.Size = New System.Drawing.Size(186, 20)
        Me.txtapematamm.TabIndex = 25
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(362, 87)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(89, 13)
        Me.Label21.TabIndex = 24
        Me.Label21.Text = "Apellido Materno:"
        '
        'txtapepatamm
        '
        Me.txtapepatamm.Location = New System.Drawing.Point(451, 61)
        Me.txtapepatamm.MaxLength = 45
        Me.txtapepatamm.Name = "txtapepatamm"
        Me.txtapepatamm.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatamm.TabIndex = 23
        '
        'txtnombreamm
        '
        Me.txtnombreamm.Location = New System.Drawing.Point(451, 38)
        Me.txtnombreamm.MaxLength = 70
        Me.txtnombreamm.Name = "txtnombreamm"
        Me.txtnombreamm.Size = New System.Drawing.Size(262, 20)
        Me.txtnombreamm.TabIndex = 21
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(364, 61)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(87, 13)
        Me.Label22.TabIndex = 22
        Me.Label22.Text = "Apellido Paterno:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(365, 38)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(50, 13)
        Me.Label23.TabIndex = 20
        Me.Label23.Text = "Nombre :"
        '
        'txtapematamp
        '
        Me.txtapematamp.Location = New System.Drawing.Point(91, 87)
        Me.txtapematamp.MaxLength = 45
        Me.txtapematamp.Name = "txtapematamp"
        Me.txtapematamp.Size = New System.Drawing.Size(186, 20)
        Me.txtapematamp.TabIndex = 17
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(489, 19)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(46, 13)
        Me.Label24.TabIndex = 19
        Me.Label24.Text = "Abuela"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(2, 87)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(89, 13)
        Me.Label25.TabIndex = 16
        Me.Label25.Text = "Apellido Materno:"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(128, 19)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(46, 13)
        Me.Label26.TabIndex = 18
        Me.Label26.Text = "Abuelo"
        '
        'txtapepatamp
        '
        Me.txtapepatamp.Location = New System.Drawing.Point(91, 61)
        Me.txtapepatamp.MaxLength = 45
        Me.txtapepatamp.Name = "txtapepatamp"
        Me.txtapepatamp.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatamp.TabIndex = 15
        '
        'txtnombreamp
        '
        Me.txtnombreamp.Location = New System.Drawing.Point(91, 38)
        Me.txtnombreamp.MaxLength = 70
        Me.txtnombreamp.Name = "txtnombreamp"
        Me.txtnombreamp.Size = New System.Drawing.Size(262, 20)
        Me.txtnombreamp.TabIndex = 13
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(4, 61)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(87, 13)
        Me.Label27.TabIndex = 14
        Me.Label27.Text = "Apellido Paterno:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(5, 38)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(50, 13)
        Me.Label28.TabIndex = 12
        Me.Label28.Text = "Nombre :"
        '
        'gpopadrinos
        '
        Me.gpopadrinos.Controls.Add(Me.txtapematmad)
        Me.gpopadrinos.Controls.Add(Me.Label29)
        Me.gpopadrinos.Controls.Add(Me.txtapepatmad)
        Me.gpopadrinos.Controls.Add(Me.txtnombremad)
        Me.gpopadrinos.Controls.Add(Me.Label30)
        Me.gpopadrinos.Controls.Add(Me.Label31)
        Me.gpopadrinos.Controls.Add(Me.txtapematpad)
        Me.gpopadrinos.Controls.Add(Me.Label32)
        Me.gpopadrinos.Controls.Add(Me.Label33)
        Me.gpopadrinos.Controls.Add(Me.Label34)
        Me.gpopadrinos.Controls.Add(Me.txtapepatpad)
        Me.gpopadrinos.Controls.Add(Me.txtnombrepad)
        Me.gpopadrinos.Controls.Add(Me.Label35)
        Me.gpopadrinos.Controls.Add(Me.Label36)
        Me.gpopadrinos.Location = New System.Drawing.Point(12, 499)
        Me.gpopadrinos.Name = "gpopadrinos"
        Me.gpopadrinos.Size = New System.Drawing.Size(727, 117)
        Me.gpopadrinos.TabIndex = 28
        Me.gpopadrinos.TabStop = False
        Me.gpopadrinos.Text = "Padrinos"
        '
        'txtapematmad
        '
        Me.txtapematmad.Location = New System.Drawing.Point(451, 87)
        Me.txtapematmad.MaxLength = 45
        Me.txtapematmad.Name = "txtapematmad"
        Me.txtapematmad.Size = New System.Drawing.Size(186, 20)
        Me.txtapematmad.TabIndex = 25
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(362, 87)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(89, 13)
        Me.Label29.TabIndex = 24
        Me.Label29.Text = "Apellido Materno:"
        '
        'txtapepatmad
        '
        Me.txtapepatmad.Location = New System.Drawing.Point(451, 61)
        Me.txtapepatmad.MaxLength = 45
        Me.txtapepatmad.Name = "txtapepatmad"
        Me.txtapepatmad.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatmad.TabIndex = 23
        '
        'txtnombremad
        '
        Me.txtnombremad.Location = New System.Drawing.Point(451, 38)
        Me.txtnombremad.MaxLength = 70
        Me.txtnombremad.Name = "txtnombremad"
        Me.txtnombremad.Size = New System.Drawing.Size(262, 20)
        Me.txtnombremad.TabIndex = 21
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(364, 61)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(87, 13)
        Me.Label30.TabIndex = 22
        Me.Label30.Text = "Apellido Paterno:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(365, 38)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(50, 13)
        Me.Label31.TabIndex = 20
        Me.Label31.Text = "Nombre :"
        '
        'txtapematpad
        '
        Me.txtapematpad.Location = New System.Drawing.Point(91, 87)
        Me.txtapematpad.MaxLength = 45
        Me.txtapematpad.Name = "txtapematpad"
        Me.txtapematpad.Size = New System.Drawing.Size(186, 20)
        Me.txtapematpad.TabIndex = 17
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(489, 19)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(52, 13)
        Me.Label32.TabIndex = 19
        Me.Label32.Text = "Madrina"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(2, 87)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(89, 13)
        Me.Label33.TabIndex = 16
        Me.Label33.Text = "Apellido Materno:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(128, 19)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(50, 13)
        Me.Label34.TabIndex = 18
        Me.Label34.Text = "Padrino"
        '
        'txtapepatpad
        '
        Me.txtapepatpad.Location = New System.Drawing.Point(91, 61)
        Me.txtapepatpad.MaxLength = 45
        Me.txtapepatpad.Name = "txtapepatpad"
        Me.txtapepatpad.Size = New System.Drawing.Size(186, 20)
        Me.txtapepatpad.TabIndex = 15
        '
        'txtnombrepad
        '
        Me.txtnombrepad.Location = New System.Drawing.Point(91, 38)
        Me.txtnombrepad.MaxLength = 70
        Me.txtnombrepad.Name = "txtnombrepad"
        Me.txtnombrepad.Size = New System.Drawing.Size(262, 20)
        Me.txtnombrepad.TabIndex = 13
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(4, 61)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(87, 13)
        Me.Label35.TabIndex = 14
        Me.Label35.Text = "Apellido Paterno:"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(5, 38)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(50, 13)
        Me.Label36.TabIndex = 12
        Me.Label36.Text = "Nombre :"
        '
        'BtnGuardar
        '
        Me.BtnGuardar.Location = New System.Drawing.Point(388, 11)
        Me.BtnGuardar.Name = "BtnGuardar"
        Me.BtnGuardar.Size = New System.Drawing.Size(75, 23)
        Me.BtnGuardar.TabIndex = 29
        Me.BtnGuardar.Text = "&Guardar"
        Me.BtnGuardar.UseVisualStyleBackColor = True
        '
        'btnCerrar
        '
        Me.btnCerrar.Location = New System.Drawing.Point(504, 12)
        Me.btnCerrar.Name = "btnCerrar"
        Me.btnCerrar.Size = New System.Drawing.Size(75, 23)
        Me.btnCerrar.TabIndex = 30
        Me.btnCerrar.Text = "&Cerrar"
        Me.btnCerrar.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(418, 49)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(23, 13)
        Me.Label37.TabIndex = 32
        Me.Label37.Text = "Dia"
        '
        'cmbdia
        '
        Me.cmbdia.FormattingEnabled = True
        Me.cmbdia.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"})
        Me.cmbdia.Location = New System.Drawing.Point(447, 46)
        Me.cmbdia.Name = "cmbdia"
        Me.cmbdia.Size = New System.Drawing.Size(43, 21)
        Me.cmbdia.TabIndex = 33
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(497, 48)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(27, 13)
        Me.Label38.TabIndex = 34
        Me.Label38.Text = "Mes"
        '
        'cmbmes
        '
        Me.cmbmes.FormattingEnabled = True
        Me.cmbmes.Items.AddRange(New Object() {"ENERO", "FEBRERO", "MARZO", "ABRIL", "MAYO", "JUNIO", "JULIO", "AGOSTO", "SEPTIEMBRE", "OCTUBRE", "NOVIEMBRE", "DICIEMBRE"})
        Me.cmbmes.Location = New System.Drawing.Point(530, 45)
        Me.cmbmes.Name = "cmbmes"
        Me.cmbmes.Size = New System.Drawing.Size(92, 21)
        Me.cmbmes.TabIndex = 35
        '
        'cmbanno
        '
        Me.cmbanno.FormattingEnabled = True
        Me.cmbanno.Location = New System.Drawing.Point(663, 45)
        Me.cmbanno.Name = "cmbanno"
        Me.cmbanno.Size = New System.Drawing.Size(58, 21)
        Me.cmbanno.TabIndex = 36
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(628, 49)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(26, 13)
        Me.Label39.TabIndex = 37
        Me.Label39.Text = "Año"
        '
        'PreRegistro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(743, 644)
        Me.Controls.Add(Me.Label39)
        Me.Controls.Add(Me.cmbanno)
        Me.Controls.Add(Me.cmbmes)
        Me.Controls.Add(Me.Label38)
        Me.Controls.Add(Me.cmbdia)
        Me.Controls.Add(Me.Label37)
        Me.Controls.Add(Me.btnCerrar)
        Me.Controls.Add(Me.BtnGuardar)
        Me.Controls.Add(Me.gpopadrinos)
        Me.Controls.Add(Me.gpoabuelosmat)
        Me.Controls.Add(Me.gpoabuelosPat)
        Me.Controls.Add(Me.gpopapas)
        Me.Controls.Add(Me.txtapemat)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtapepat)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtnombre)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PreRegistro"
        Me.Text = "PreRegistro"
        Me.gpopapas.ResumeLayout(False)
        Me.gpopapas.PerformLayout()
        Me.gpoabuelosPat.ResumeLayout(False)
        Me.gpoabuelosPat.PerformLayout()
        Me.gpoabuelosmat.ResumeLayout(False)
        Me.gpoabuelosmat.PerformLayout()
        Me.gpopadrinos.ResumeLayout(False)
        Me.gpopadrinos.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents txtnombre As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtapepat As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtapemat As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents gpopapas As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtapematpapa As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtapepatpapa As System.Windows.Forms.TextBox
    Friend WithEvents txtnombrepapa As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtapematmama As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtapepatmama As System.Windows.Forms.TextBox
    Friend WithEvents txtnombremama As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents gpoabuelosPat As System.Windows.Forms.GroupBox
    Friend WithEvents txtapematapm As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtapepatapm As System.Windows.Forms.TextBox
    Friend WithEvents txtnombreapm As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtapematapp As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtapepatapp As System.Windows.Forms.TextBox
    Friend WithEvents txtnombreapp As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents gpoabuelosmat As System.Windows.Forms.GroupBox
    Friend WithEvents txtapematamm As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents txtapepatamm As System.Windows.Forms.TextBox
    Friend WithEvents txtnombreamm As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtapematamp As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtapepatamp As System.Windows.Forms.TextBox
    Friend WithEvents txtnombreamp As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents gpopadrinos As System.Windows.Forms.GroupBox
    Friend WithEvents txtapematmad As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents txtapepatmad As System.Windows.Forms.TextBox
    Friend WithEvents txtnombremad As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents txtapematpad As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents txtapepatpad As System.Windows.Forms.TextBox
    Friend WithEvents txtnombrepad As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents BtnGuardar As System.Windows.Forms.Button
    Friend WithEvents btnCerrar As System.Windows.Forms.Button
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents cmbdia As System.Windows.Forms.ComboBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents cmbmes As System.Windows.Forms.ComboBox
    Friend WithEvents cmbanno As System.Windows.Forms.ComboBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
End Class
